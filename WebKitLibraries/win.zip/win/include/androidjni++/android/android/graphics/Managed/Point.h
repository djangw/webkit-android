// Generated from ../../interfaces/Point.in
// Last modified: Tue Feb 21 11:04:32 2017
// THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.
#ifndef ANDROIDJNI_GENERATED_android_graphics_Managed_Point_h
#define ANDROIDJNI_GENERATED_android_graphics_Managed_Point_h

#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>
namespace android { namespace graphics { namespace Managed { class Point ; }}}
typedef class android::graphics::Managed::Point android_graphics_Managed_Point ;

namespace android {
namespace graphics {
namespace Natives {
class Point;
} // namespace Natives

namespace Managed {

typedef android_graphics_Managed_Point Point;

class Point {
#define CLASS_EXPORT JNI_EXPORT
public:
    class NativeBindings;
    friend class NativeBindings;
    friend class Natives::Point;
    
    virtual ~Point() { }

    template<typename T, typename... Args> static inline std::shared_ptr<T> create(Args&&... arguments)
    {
        static_assert(std::is_base_of<Point, T>::value, "Type T is not a kind of Point.");
        std::shared_ptr<Point> uninitialized = create([=] () { return new T(); }, [&] (Point* ptr) { static_cast<T*>(ptr)->INIT(arguments...); });
        return std::static_pointer_cast<T>(uninitialized);
    }
    
    template<typename T> static inline void runtimeLink()
    {
        static_assert(std::is_base_of<Point, T>::value, "Type T is not a kind of Point.");
        overrideCTOR([=] () { return new T(); });
    }

    int32_t x;

    int32_t y;

    CLASS_EXPORT static std::shared_ptr<Point> create();

    CLASS_EXPORT static std::shared_ptr<Point> create(int32_t x
        , int32_t y);

    CLASS_EXPORT static std::shared_ptr<Point> create(const std::shared_ptr<Point>& src);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void set(int32_t x
        , int32_t y);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void negate();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void offset(int32_t dx
        , int32_t dy);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool equals(int32_t x
        , int32_t y);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool equals(const std::shared_ptr<void>& o);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int32_t hashCode();

private:
    static Point* CTOR();
    
    // NOTE: OVERRIDE DEFAULT CONSTRUCTOR IF CLASS IS BEING REDEFINED USING INHERITANCE
    CLASS_EXPORT static void overrideCTOR(std::function<Point* ()>);

public:
    // TODO: DEFINE PRIVATE CLASS(IF NEEDED)
    class Private { public: virtual ~Private() { } };
    template<typename T> T& p() { return static_cast<T&>(*m_private); }

    // NOTE: SHOULD BE CALLED DURING MODULE INITIALIZATION
    CLASS_EXPORT static bool registerClass();

protected:
    CLASS_EXPORT Point();

    CLASS_EXPORT static std::shared_ptr<Point> create(std::function<Point* ()>, std::function<void (Point*)>);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT(int32_t x
        , int32_t y);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT(const std::shared_ptr<Point>& src);

    std::unique_ptr<Private> m_private;
}; // class Point

#undef CLASS_EXPORT

} // namespace Managed
} // namespace graphics
} // namespace android

#endif // End of File
