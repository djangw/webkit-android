// Generated from ../../interfaces/Rect.in
// Last modified: Tue Feb 21 11:04:32 2017
// THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.
#ifndef ANDROIDJNI_GENERATED_android_graphics_Managed_Rect_h
#define ANDROIDJNI_GENERATED_android_graphics_Managed_Rect_h

#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>
namespace android { namespace graphics { namespace Managed { class Rect ; }}}
typedef class android::graphics::Managed::Rect android_graphics_Managed_Rect ;

namespace android {
namespace graphics {
namespace Natives {
class Rect;
} // namespace Natives

namespace Managed {

typedef android_graphics_Managed_Rect Rect;

class Rect {
#define CLASS_EXPORT JNI_EXPORT
public:
    class NativeBindings;
    friend class NativeBindings;
    friend class Natives::Rect;
    
    virtual ~Rect() { }

    template<typename T, typename... Args> static inline std::shared_ptr<T> create(Args&&... arguments)
    {
        static_assert(std::is_base_of<Rect, T>::value, "Type T is not a kind of Rect.");
        std::shared_ptr<Rect> uninitialized = create([=] () { return new T(); }, [&] (Rect* ptr) { static_cast<T*>(ptr)->INIT(arguments...); });
        return std::static_pointer_cast<T>(uninitialized);
    }
    
    template<typename T> static inline void runtimeLink()
    {
        static_assert(std::is_base_of<Rect, T>::value, "Type T is not a kind of Rect.");
        overrideCTOR([=] () { return new T(); });
    }

    int32_t left;

    int32_t top;

    int32_t right;

    int32_t bottom;

    CLASS_EXPORT static std::shared_ptr<Rect> create();

    CLASS_EXPORT static std::shared_ptr<Rect> create(int32_t left
        , int32_t top
        , int32_t right
        , int32_t bottom);

    CLASS_EXPORT static std::shared_ptr<Rect> create(const std::shared_ptr<Rect>& r);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool equals(const std::shared_ptr<void>& o);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int32_t hashCode();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool isEmpty();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int32_t width();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int32_t height();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int32_t centerX();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int32_t centerY();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual float exactCenterX();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual float exactCenterY();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void setEmpty();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void set(int32_t left
        , int32_t top
        , int32_t right
        , int32_t bottom);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void set(const std::shared_ptr<Rect>& src);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void offset(int32_t dx
        , int32_t dy);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void offsetTo(int32_t newLeft
        , int32_t newTop);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void inset(int32_t dx
        , int32_t dy);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool contains(int32_t x
        , int32_t y);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool contains(int32_t left
        , int32_t top
        , int32_t right
        , int32_t bottom);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool contains(const std::shared_ptr<Rect>& r);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool intersect(int32_t left
        , int32_t top
        , int32_t right
        , int32_t bottom);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool intersect(const std::shared_ptr<Rect>& r);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool setIntersect(const std::shared_ptr<Rect>& a
        , const std::shared_ptr<Rect>& b);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool intersects(int32_t left
        , int32_t top
        , int32_t right
        , int32_t bottom);

    // TODO: IMPLEMENT
    CLASS_EXPORT static bool intersects(const std::shared_ptr<Rect>& a
        , const std::shared_ptr<Rect>& b);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void sort();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void scale(float scale);

private:
    static Rect* CTOR();
    
    // NOTE: OVERRIDE DEFAULT CONSTRUCTOR IF CLASS IS BEING REDEFINED USING INHERITANCE
    CLASS_EXPORT static void overrideCTOR(std::function<Rect* ()>);

public:
    // TODO: DEFINE PRIVATE CLASS(IF NEEDED)
    class Private { public: virtual ~Private() { } };
    template<typename T> T& p() { return static_cast<T&>(*m_private); }

    // NOTE: SHOULD BE CALLED DURING MODULE INITIALIZATION
    CLASS_EXPORT static bool registerClass();

protected:
    CLASS_EXPORT Rect();

    CLASS_EXPORT static std::shared_ptr<Rect> create(std::function<Rect* ()>, std::function<void (Rect*)>);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT(int32_t left
        , int32_t top
        , int32_t right
        , int32_t bottom);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT(const std::shared_ptr<Rect>& r);

    std::unique_ptr<Private> m_private;
}; // class Rect

#undef CLASS_EXPORT

} // namespace Managed
} // namespace graphics
} // namespace android

#endif // End of File
