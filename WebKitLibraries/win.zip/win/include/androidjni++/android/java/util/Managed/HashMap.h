// Generated from ../../interfaces/HashMap.in
// Last modified: Tue Feb 21 11:04:32 2017
// THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.
#ifndef ANDROIDJNI_GENERATED_java_util_Managed_HashMap_h
#define ANDROIDJNI_GENERATED_java_util_Managed_HashMap_h

#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace java {
namespace util {
namespace Natives {
class HashMap;
} // namespace Natives

namespace Managed {

class HashMap {
#define CLASS_EXPORT JNI_EXPORT
public:
    class NativeBindings;
    friend class NativeBindings;
    friend class Natives::HashMap;
    
    virtual ~HashMap() { }

    template<typename T, typename... Args> static inline std::shared_ptr<T> create(Args&&... arguments)
    {
        static_assert(std::is_base_of<HashMap, T>::value, "Type T is not a kind of HashMap.");
        std::shared_ptr<HashMap> uninitialized = create([=] () { return new T(); }, [&] (HashMap* ptr) { static_cast<T*>(ptr)->INIT(arguments...); });
        return std::static_pointer_cast<T>(uninitialized);
    }
    
    template<typename T> static inline void runtimeLink()
    {
        static_assert(std::is_base_of<HashMap, T>::value, "Type T is not a kind of HashMap.");
        overrideCTOR([=] () { return new T(); });
    }

    CLASS_EXPORT static std::shared_ptr<HashMap> create();

    // NOTE: SUPPLEMENTAL, IMPLEMENT IF NEEDED
    using Data = std::map<std::shared_ptr<void>, std::shared_ptr<void>>;

    CLASS_EXPORT static std::shared_ptr<HashMap> create(int32_t capacity);

    CLASS_EXPORT static std::shared_ptr<HashMap> create(int32_t capacity
        , float loadFactor);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void clear();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual std::shared_ptr<void> clone();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool containsKey(const std::shared_ptr<void>& key);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool containsValue(const std::shared_ptr<void>& value);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual std::shared_ptr<void> get(const std::shared_ptr<void>& key);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool isEmpty();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual std::shared_ptr<void> put(const std::shared_ptr<void>& key
        , const std::shared_ptr<void>& value);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual std::shared_ptr<void> remove(const std::shared_ptr<void>& key);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int32_t size();

    // NOTE: SUPPLEMENTAL, IMPLEMENT IF NEEDED
    CLASS_EXPORT const Data& data();

private:
    static HashMap* CTOR();
    
    // NOTE: OVERRIDE DEFAULT CONSTRUCTOR IF CLASS IS BEING REDEFINED USING INHERITANCE
    CLASS_EXPORT static void overrideCTOR(std::function<HashMap* ()>);

public:
    // TODO: DEFINE PRIVATE CLASS(IF NEEDED)
    class Private { public: virtual ~Private() { } };
    template<typename T> T& p() { return static_cast<T&>(*m_private); }

    // NOTE: SHOULD BE CALLED DURING MODULE INITIALIZATION
    CLASS_EXPORT static bool registerClass();

protected:
    CLASS_EXPORT HashMap();

    CLASS_EXPORT static std::shared_ptr<HashMap> create(std::function<HashMap* ()>, std::function<void (HashMap*)>);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT(int32_t capacity);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT(int32_t capacity
        , float loadFactor);

    std::unique_ptr<Private> m_private;
}; // class HashMap

#undef CLASS_EXPORT

} // namespace Managed
} // namespace util
} // namespace java

#endif // End of File
