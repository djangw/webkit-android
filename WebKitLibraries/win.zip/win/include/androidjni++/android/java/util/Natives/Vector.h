// Generated from ../../interfaces/Vector.in
// Last modified: Tue Feb 21 11:04:32 2017
// THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.
#ifndef ANDROIDJNI_GENERATED_java_util_Natives_Vector_h
#define ANDROIDJNI_GENERATED_java_util_Natives_Vector_h

#include <androidjni/JNIIncludes.h>

namespace java {
namespace util {
namespace Managed {
class Vector;
} // namespace Managed

namespace Natives {

class Vector : public JNI::NativeObject {
#define CLASS_EXPORT JNI_EXPORT
public:
    class NativeBindings;
    friend class NativeBindings;
    friend class Managed::Vector;
    
    virtual ~Vector() { }

    // TODO: IMPLEMENT
    static Vector* CTOR();

    static JNI::PassLocalRef<Vector> fromRef(JNI::ref_t);
    static JNI::PassLocalRef<Vector> fromPtr(const std::shared_ptr<Managed::Vector>&);
    template<typename... T> static JNI::PassLocalRef<Vector> create(T...);
    template<typename T> T castTo();

    CLASS_EXPORT static JNI::PassLocalRef<Vector> create();

    CLASS_EXPORT static JNI::PassLocalRef<Vector> create(int32_t capacity);

    CLASS_EXPORT static JNI::PassLocalRef<Vector> create(int32_t capacity
        , int32_t capacityIncrement);

    CLASS_EXPORT virtual void add(int32_t location
        , JNI::PassLocalRef<JNI::AnyObject> object);

    CLASS_EXPORT virtual bool add(JNI::PassLocalRef<JNI::AnyObject> object);

    CLASS_EXPORT virtual void addElement(JNI::PassLocalRef<JNI::AnyObject> object);

    CLASS_EXPORT virtual int32_t capacity();

    CLASS_EXPORT virtual void clear();

    CLASS_EXPORT virtual JNI::PassLocalRef<JNI::AnyObject> clone();

    CLASS_EXPORT virtual bool contains(JNI::PassLocalRef<JNI::AnyObject> object);

    CLASS_EXPORT virtual JNI::PassLocalRef<JNI::AnyObject> elementAt(int32_t location);

    CLASS_EXPORT virtual void ensureCapacity(int32_t minimumCapacity);

    CLASS_EXPORT virtual bool equals(JNI::PassLocalRef<JNI::AnyObject> object);

    CLASS_EXPORT virtual JNI::PassLocalRef<JNI::AnyObject> firstElement();

    CLASS_EXPORT virtual JNI::PassLocalRef<JNI::AnyObject> get(int32_t location);

    CLASS_EXPORT virtual int32_t hashCode();

    CLASS_EXPORT virtual int32_t indexOf(JNI::PassLocalRef<JNI::AnyObject> object);

    CLASS_EXPORT virtual int32_t indexOf(JNI::PassLocalRef<JNI::AnyObject> object
        , int32_t location);

    CLASS_EXPORT virtual void insertElementAt(JNI::PassLocalRef<JNI::AnyObject> object
        , int32_t location);

    CLASS_EXPORT virtual bool isEmpty();

    CLASS_EXPORT virtual JNI::PassLocalRef<JNI::AnyObject> lastElement();

    CLASS_EXPORT virtual int32_t lastIndexOf(JNI::PassLocalRef<JNI::AnyObject> object);

    CLASS_EXPORT virtual int32_t lastIndexOf(JNI::PassLocalRef<JNI::AnyObject> object
        , int32_t location);

    CLASS_EXPORT virtual JNI::PassLocalRef<JNI::AnyObject> remove(int32_t location);

    CLASS_EXPORT virtual bool remove(JNI::PassLocalRef<JNI::AnyObject> object);

    CLASS_EXPORT virtual void removeAllElements();

    CLASS_EXPORT virtual bool removeElement(JNI::PassLocalRef<JNI::AnyObject> object);

    CLASS_EXPORT virtual void removeElementAt(int32_t location);

    CLASS_EXPORT virtual JNI::PassLocalRef<JNI::AnyObject> set(int32_t location
        , JNI::PassLocalRef<JNI::AnyObject> object);

    CLASS_EXPORT virtual void setElementAt(JNI::PassLocalRef<JNI::AnyObject> object
        , int32_t location);

    CLASS_EXPORT virtual void setSize(int32_t length);

    CLASS_EXPORT virtual int32_t size();

    CLASS_EXPORT virtual void trimToSize();

public:
    // TODO: DEFINE PRIVATE CLASS(IF NEEDED)
    class Private { public: virtual ~Private() { } };
    template<typename T> T& p() { return static_cast<T&>(*m_private); }

    // NOTE: SHOULD BE CALLED DURING MODULE INITIALIZATION
    CLASS_EXPORT static bool registerClass();

protected:
    CLASS_EXPORT Vector();

    std::unique_ptr<Private> m_private;
}; // class Vector

#undef CLASS_EXPORT

} // namespace Natives
} // namespace util
} // namespace java

#endif // End of File
