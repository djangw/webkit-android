// Generated from ../../interfaces/Vector.in
// Last modified: Tue Feb 21 11:04:32 2017
// THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.
#ifndef ANDROIDJNI_GENERATED_java_util_Managed_Vector_h
#define ANDROIDJNI_GENERATED_java_util_Managed_Vector_h

#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace java {
namespace util {
namespace Natives {
class Vector;
} // namespace Natives

namespace Managed {

class Vector {
#define CLASS_EXPORT JNI_EXPORT
public:
    class NativeBindings;
    friend class NativeBindings;
    friend class Natives::Vector;
    
    virtual ~Vector() { }

    template<typename T, typename... Args> static inline std::shared_ptr<T> create(Args&&... arguments)
    {
        static_assert(std::is_base_of<Vector, T>::value, "Type T is not a kind of Vector.");
        std::shared_ptr<Vector> uninitialized = create([=] () { return new T(); }, [&] (Vector* ptr) { static_cast<T*>(ptr)->INIT(arguments...); });
        return std::static_pointer_cast<T>(uninitialized);
    }
    
    template<typename T> static inline void runtimeLink()
    {
        static_assert(std::is_base_of<Vector, T>::value, "Type T is not a kind of Vector.");
        overrideCTOR([=] () { return new T(); });
    }

    CLASS_EXPORT static std::shared_ptr<Vector> create();

    // NOTE: SUPPLEMENTAL, IMPLEMENT IF NEEDED
    using Data = std::vector<std::shared_ptr<void>>;

    CLASS_EXPORT static std::shared_ptr<Vector> create(int32_t capacity);

    CLASS_EXPORT static std::shared_ptr<Vector> create(int32_t capacity
        , int32_t capacityIncrement);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void add(int32_t location
        , const std::shared_ptr<void>& object);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool add(const std::shared_ptr<void>& object);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void addElement(const std::shared_ptr<void>& object);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int32_t capacity();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void clear();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual std::shared_ptr<void> clone();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool contains(const std::shared_ptr<void>& object);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual std::shared_ptr<void> elementAt(int32_t location);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void ensureCapacity(int32_t minimumCapacity);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool equals(const std::shared_ptr<void>& object);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual std::shared_ptr<void> firstElement();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual std::shared_ptr<void> get(int32_t location);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int32_t hashCode();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int32_t indexOf(const std::shared_ptr<void>& object);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int32_t indexOf(const std::shared_ptr<void>& object
        , int32_t location);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void insertElementAt(const std::shared_ptr<void>& object
        , int32_t location);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool isEmpty();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual std::shared_ptr<void> lastElement();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int32_t lastIndexOf(const std::shared_ptr<void>& object);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int32_t lastIndexOf(const std::shared_ptr<void>& object
        , int32_t location);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual std::shared_ptr<void> remove(int32_t location);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool remove(const std::shared_ptr<void>& object);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void removeAllElements();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool removeElement(const std::shared_ptr<void>& object);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void removeElementAt(int32_t location);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual std::shared_ptr<void> set(int32_t location
        , const std::shared_ptr<void>& object);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void setElementAt(const std::shared_ptr<void>& object
        , int32_t location);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void setSize(int32_t length);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int32_t size();

    // NOTE: SUPPLEMENTAL, IMPLEMENT IF NEEDED
    CLASS_EXPORT const Data& data();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void trimToSize();

private:
    static Vector* CTOR();
    
    // NOTE: OVERRIDE DEFAULT CONSTRUCTOR IF CLASS IS BEING REDEFINED USING INHERITANCE
    CLASS_EXPORT static void overrideCTOR(std::function<Vector* ()>);

public:
    // TODO: DEFINE PRIVATE CLASS(IF NEEDED)
    class Private { public: virtual ~Private() { } };
    template<typename T> T& p() { return static_cast<T&>(*m_private); }

    // NOTE: SHOULD BE CALLED DURING MODULE INITIALIZATION
    CLASS_EXPORT static bool registerClass();

protected:
    CLASS_EXPORT Vector();

    CLASS_EXPORT static std::shared_ptr<Vector> create(std::function<Vector* ()>, std::function<void (Vector*)>);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT(int32_t capacity);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT(int32_t capacity
        , int32_t capacityIncrement);

    std::unique_ptr<Private> m_private;
}; // class Vector

#undef CLASS_EXPORT

} // namespace Managed
} // namespace util
} // namespace java

#endif // End of File
