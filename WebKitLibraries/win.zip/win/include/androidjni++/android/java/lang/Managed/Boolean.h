// Generated from ../../interfaces/Boolean.in
// Last modified: Tue Feb 21 11:04:32 2017
// THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.
#ifndef ANDROIDJNI_GENERATED_java_lang_Managed_Boolean_h
#define ANDROIDJNI_GENERATED_java_lang_Managed_Boolean_h

#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace java {
namespace lang {
namespace Natives {
class Boolean;
} // namespace Natives

namespace Managed {

class Boolean {
#define CLASS_EXPORT JNI_EXPORT
public:
    class NativeBindings;
    friend class NativeBindings;
    friend class Natives::Boolean;
    
    virtual ~Boolean() { }

    template<typename T, typename... Args> static inline std::shared_ptr<T> create(Args&&... arguments)
    {
        static_assert(std::is_base_of<Boolean, T>::value, "Type T is not a kind of Boolean.");
        std::shared_ptr<Boolean> uninitialized = create([=] () { return new T(); }, [&] (Boolean* ptr) { static_cast<T*>(ptr)->INIT(arguments...); });
        return std::static_pointer_cast<T>(uninitialized);
    }
    
    template<typename T> static inline void runtimeLink()
    {
        static_assert(std::is_base_of<Boolean, T>::value, "Type T is not a kind of Boolean.");
        overrideCTOR([=] () { return new T(); });
    }

    bool value;

    CLASS_EXPORT static std::shared_ptr<Boolean> create(bool value);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual bool booleanValue();

private:
    static Boolean* CTOR();
    
    // NOTE: OVERRIDE DEFAULT CONSTRUCTOR IF CLASS IS BEING REDEFINED USING INHERITANCE
    CLASS_EXPORT static void overrideCTOR(std::function<Boolean* ()>);

public:
    // TODO: DEFINE PRIVATE CLASS(IF NEEDED)
    class Private { public: virtual ~Private() { } };
    template<typename T> T& p() { return static_cast<T&>(*m_private); }

    // NOTE: SHOULD BE CALLED DURING MODULE INITIALIZATION
    CLASS_EXPORT static bool registerClass();

protected:
    CLASS_EXPORT Boolean();

    CLASS_EXPORT static std::shared_ptr<Boolean> create(std::function<Boolean* ()>, std::function<void (Boolean*)>);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT(bool value);

    std::unique_ptr<Private> m_private;
}; // class Boolean

#undef CLASS_EXPORT

} // namespace Managed
} // namespace lang
} // namespace java

#endif // End of File
