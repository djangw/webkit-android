// Generated from ../../interfaces/Long.in
// Last modified: Tue Feb 21 11:04:32 2017
// THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.
#ifndef ANDROIDJNI_GENERATED_java_lang_Managed_Long_h
#define ANDROIDJNI_GENERATED_java_lang_Managed_Long_h

#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace java {
namespace lang {
namespace Natives {
class Long;
} // namespace Natives

namespace Managed {

class Long {
#define CLASS_EXPORT JNI_EXPORT
public:
    class NativeBindings;
    friend class NativeBindings;
    friend class Natives::Long;
    
    virtual ~Long() { }

    template<typename T, typename... Args> static inline std::shared_ptr<T> create(Args&&... arguments)
    {
        static_assert(std::is_base_of<Long, T>::value, "Type T is not a kind of Long.");
        std::shared_ptr<Long> uninitialized = create([=] () { return new T(); }, [&] (Long* ptr) { static_cast<T*>(ptr)->INIT(arguments...); });
        return std::static_pointer_cast<T>(uninitialized);
    }
    
    template<typename T> static inline void runtimeLink()
    {
        static_assert(std::is_base_of<Long, T>::value, "Type T is not a kind of Long.");
        overrideCTOR([=] () { return new T(); });
    }

    static const int64_t MAX_VALUE = 0x7FFFFFFFFFFFFFFFL;

    static const int64_t MIN_VALUE = 0x8000000000000000L;

    static const int32_t SIZE = 64;

    int64_t value;

    CLASS_EXPORT static std::shared_ptr<Long> create(int64_t value);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int8_t byteValue();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual double doubleValue();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual float floatValue();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int32_t intValue();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int64_t longValue();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int16_t shortValue();

private:
    static Long* CTOR();
    
    // NOTE: OVERRIDE DEFAULT CONSTRUCTOR IF CLASS IS BEING REDEFINED USING INHERITANCE
    CLASS_EXPORT static void overrideCTOR(std::function<Long* ()>);

public:
    // TODO: DEFINE PRIVATE CLASS(IF NEEDED)
    class Private { public: virtual ~Private() { } };
    template<typename T> T& p() { return static_cast<T&>(*m_private); }

    // NOTE: SHOULD BE CALLED DURING MODULE INITIALIZATION
    CLASS_EXPORT static bool registerClass();

protected:
    CLASS_EXPORT Long();

    CLASS_EXPORT static std::shared_ptr<Long> create(std::function<Long* ()>, std::function<void (Long*)>);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT(int64_t value);

    std::unique_ptr<Private> m_private;
}; // class Long

#undef CLASS_EXPORT

} // namespace Managed
} // namespace lang
} // namespace java

#endif // End of File
