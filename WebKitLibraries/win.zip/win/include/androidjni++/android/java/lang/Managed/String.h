// Generated from ../../interfaces/String.in
// Last modified: Tue Feb 21 11:04:32 2017
// THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.
#ifndef ANDROIDJNI_GENERATED_java_lang_Managed_String_h
#define ANDROIDJNI_GENERATED_java_lang_Managed_String_h

#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace java {
namespace lang {
namespace Natives {
class String;
} // namespace Natives

namespace Managed {

class String {
#define CLASS_EXPORT JNI_EXPORT
public:
    class NativeBindings;
    friend class NativeBindings;
    friend class Natives::String;
    
    virtual ~String() { }

    template<typename T, typename... Args> static inline std::shared_ptr<T> create(Args&&... arguments)
    {
        static_assert(std::is_base_of<String, T>::value, "Type T is not a kind of String.");
        std::shared_ptr<String> uninitialized = create([=] () { return new T(); }, [&] (String* ptr) { static_cast<T*>(ptr)->INIT(arguments...); });
        return std::static_pointer_cast<T>(uninitialized);
    }
    
    template<typename T> static inline void runtimeLink()
    {
        static_assert(std::is_base_of<String, T>::value, "Type T is not a kind of String.");
        overrideCTOR([=] () { return new T(); });
    }

    CLASS_EXPORT static std::shared_ptr<String> create();

    CLASS_EXPORT static std::shared_ptr<String> create(const std::vector<int8_t>& data);

    // NOTE: SUPPLEMENTAL, IMPLEMENT IF NEEDED
    CLASS_EXPORT static std::shared_ptr<String> create(const char*);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual std::vector<int8_t> getBytes();

private:
    static String* CTOR();
    
    // NOTE: OVERRIDE DEFAULT CONSTRUCTOR IF CLASS IS BEING REDEFINED USING INHERITANCE
    CLASS_EXPORT static void overrideCTOR(std::function<String* ()>);

public:
    // TODO: DEFINE PRIVATE CLASS(IF NEEDED)
    class Private { public: virtual ~Private() { } };
    template<typename T> T& p() { return static_cast<T&>(*m_private); }

    // NOTE: SHOULD BE CALLED DURING MODULE INITIALIZATION
    CLASS_EXPORT static bool registerClass();

protected:
    CLASS_EXPORT String();

    CLASS_EXPORT static std::shared_ptr<String> create(std::function<String* ()>, std::function<void (String*)>);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT(const std::vector<int8_t>& data);

    std::unique_ptr<Private> m_private;
}; // class String

#undef CLASS_EXPORT

} // namespace Managed
} // namespace lang
} // namespace java

#endif // End of File
