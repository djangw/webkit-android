// Generated from ../../interfaces/Integer.in
// Last modified: Tue Feb 21 11:04:32 2017
// THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.
#ifndef ANDROIDJNI_GENERATED_java_lang_Managed_Integer_h
#define ANDROIDJNI_GENERATED_java_lang_Managed_Integer_h

#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace java {
namespace lang {
namespace Natives {
class Integer;
} // namespace Natives

namespace Managed {

class Integer {
#define CLASS_EXPORT JNI_EXPORT
public:
    class NativeBindings;
    friend class NativeBindings;
    friend class Natives::Integer;
    
    virtual ~Integer() { }

    template<typename T, typename... Args> static inline std::shared_ptr<T> create(Args&&... arguments)
    {
        static_assert(std::is_base_of<Integer, T>::value, "Type T is not a kind of Integer.");
        std::shared_ptr<Integer> uninitialized = create([=] () { return new T(); }, [&] (Integer* ptr) { static_cast<T*>(ptr)->INIT(arguments...); });
        return std::static_pointer_cast<T>(uninitialized);
    }
    
    template<typename T> static inline void runtimeLink()
    {
        static_assert(std::is_base_of<Integer, T>::value, "Type T is not a kind of Integer.");
        overrideCTOR([=] () { return new T(); });
    }

    static const int32_t MAX_VALUE = 0x7FFFFFFF;

    static const int32_t MIN_VALUE = 0x80000000;

    static const int32_t SIZE = 32;

    int32_t value;

    CLASS_EXPORT static std::shared_ptr<Integer> create(int32_t value);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int8_t byteValue();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual float floatValue();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int32_t intValue();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int64_t longValue();

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual int16_t shortValue();

private:
    static Integer* CTOR();
    
    // NOTE: OVERRIDE DEFAULT CONSTRUCTOR IF CLASS IS BEING REDEFINED USING INHERITANCE
    CLASS_EXPORT static void overrideCTOR(std::function<Integer* ()>);

public:
    // TODO: DEFINE PRIVATE CLASS(IF NEEDED)
    class Private { public: virtual ~Private() { } };
    template<typename T> T& p() { return static_cast<T&>(*m_private); }

    // NOTE: SHOULD BE CALLED DURING MODULE INITIALIZATION
    CLASS_EXPORT static bool registerClass();

protected:
    CLASS_EXPORT Integer();

    CLASS_EXPORT static std::shared_ptr<Integer> create(std::function<Integer* ()>, std::function<void (Integer*)>);

    // TODO: IMPLEMENT
    CLASS_EXPORT virtual void INIT(int32_t value);

    std::unique_ptr<Private> m_private;
}; // class Integer

#undef CLASS_EXPORT

} // namespace Managed
} // namespace lang
} // namespace java

#endif // End of File
