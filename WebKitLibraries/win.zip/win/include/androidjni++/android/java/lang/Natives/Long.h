// Generated from ../../interfaces/Long.in
// Last modified: Tue Feb 21 11:04:32 2017
// THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.
#ifndef ANDROIDJNI_GENERATED_java_lang_Natives_Long_h
#define ANDROIDJNI_GENERATED_java_lang_Natives_Long_h

#include <androidjni/JNIIncludes.h>

namespace java {
namespace lang {
namespace Managed {
class Long;
} // namespace Managed

namespace Natives {

class Long : public JNI::NativeObject {
#define CLASS_EXPORT JNI_EXPORT
public:
    class NativeBindings;
    friend class NativeBindings;
    friend class Managed::Long;
    
    virtual ~Long() { }

    // TODO: IMPLEMENT
    static Long* CTOR();

    static JNI::PassLocalRef<Long> fromRef(JNI::ref_t);
    static JNI::PassLocalRef<Long> fromPtr(const std::shared_ptr<Managed::Long>&);
    template<typename... T> static JNI::PassLocalRef<Long> create(T...);
    template<typename T> T castTo();

    static const int64_t MAX_VALUE = 0x7FFFFFFFFFFFFFFFL;

    static const int64_t MIN_VALUE = 0x8000000000000000L;

    static const int32_t SIZE = 64;

    FIELD_INTERFACE(value, int64_t);

    CLASS_EXPORT static JNI::PassLocalRef<Long> create(int64_t value);

    CLASS_EXPORT virtual int8_t byteValue();

    CLASS_EXPORT virtual double doubleValue();

    CLASS_EXPORT virtual float floatValue();

    CLASS_EXPORT virtual int32_t intValue();

    CLASS_EXPORT virtual int64_t longValue();

    CLASS_EXPORT virtual int16_t shortValue();

public:
    // TODO: DEFINE PRIVATE CLASS(IF NEEDED)
    class Private { public: virtual ~Private() { } };
    template<typename T> T& p() { return static_cast<T&>(*m_private); }

    // NOTE: SHOULD BE CALLED DURING MODULE INITIALIZATION
    CLASS_EXPORT static bool registerClass();

protected:
    CLASS_EXPORT Long();

    std::unique_ptr<Private> m_private;
}; // class Long

#undef CLASS_EXPORT

} // namespace Natives
} // namespace lang
} // namespace java

#endif // End of File
