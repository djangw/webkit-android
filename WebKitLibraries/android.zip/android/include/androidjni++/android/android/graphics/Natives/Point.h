// Generated from ../../interfaces/Point.in
// Last modified: Tue Feb 21 11:04:32 2017
// THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.
#ifndef ANDROIDJNI_GENERATED_android_graphics_Natives_Point_h
#define ANDROIDJNI_GENERATED_android_graphics_Natives_Point_h

#include <androidjni/JNIIncludes.h>
namespace android { namespace graphics { namespace Natives { class Point ; }}}
typedef class android::graphics::Natives::Point android_graphics_Natives_Point ;

namespace android {
namespace graphics {
namespace Managed {
class Point;
} // namespace Managed

namespace Natives {

typedef android_graphics_Natives_Point Point;

class Point : public JNI::NativeObject {
#define CLASS_EXPORT JNI_EXPORT
public:
    class NativeBindings;
    friend class NativeBindings;
    friend class Managed::Point;
    
    virtual ~Point() { }

    // TODO: IMPLEMENT
    static Point* CTOR();

    static JNI::PassLocalRef<Point> fromRef(JNI::ref_t);
    static JNI::PassLocalRef<Point> fromPtr(const std::shared_ptr<Managed::Point>&);
    template<typename... T> static JNI::PassLocalRef<Point> create(T...);
    template<typename T> T castTo();

    FIELD_INTERFACE(x, int32_t);

    FIELD_INTERFACE(y, int32_t);

    CLASS_EXPORT static JNI::PassLocalRef<Point> create();

    CLASS_EXPORT static JNI::PassLocalRef<Point> create(int32_t x
        , int32_t y);

    CLASS_EXPORT static JNI::PassLocalRef<Point> create(JNI::PassLocalRef<Point> src);

    CLASS_EXPORT virtual void set(int32_t x
        , int32_t y);

    CLASS_EXPORT virtual void negate();

    CLASS_EXPORT virtual void offset(int32_t dx
        , int32_t dy);

    CLASS_EXPORT virtual bool equals(int32_t x
        , int32_t y);

    CLASS_EXPORT virtual bool equals(JNI::PassLocalRef<JNI::AnyObject> o);

    CLASS_EXPORT virtual int32_t hashCode();

public:
    // TODO: DEFINE PRIVATE CLASS(IF NEEDED)
    class Private { public: virtual ~Private() { } };
    template<typename T> T& p() { return static_cast<T&>(*m_private); }

    // NOTE: SHOULD BE CALLED DURING MODULE INITIALIZATION
    CLASS_EXPORT static bool registerClass();

protected:
    CLASS_EXPORT Point();

    std::unique_ptr<Private> m_private;
}; // class Point

#undef CLASS_EXPORT

} // namespace Natives
} // namespace graphics
} // namespace android

#endif // End of File
