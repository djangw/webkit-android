// Generated from ../../interfaces/Rect.in
// Last modified: Fri Feb 24 11:50:24 2017
// THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.
#ifndef ANDROIDJNI_GENERATED_android_graphics_Natives_Rect_h
#define ANDROIDJNI_GENERATED_android_graphics_Natives_Rect_h

#include <androidjni/JNIIncludes.h>
namespace android { namespace graphics { namespace Natives { class Rect ; }}}
typedef class android::graphics::Natives::Rect android_graphics_Natives_Rect ;

namespace android {
namespace graphics {
namespace Managed {
class Rect;
} // namespace Managed

namespace Natives {

typedef android_graphics_Natives_Rect Rect;

class Rect : public JNI::NativeObject {
#define CLASS_EXPORT JNI_EXPORT
public:
    class NativeBindings;
    friend class NativeBindings;
    friend class Managed::Rect;
    
    virtual ~Rect() { }

    // TODO: IMPLEMENT
    static Rect* CTOR();

    static JNI::PassLocalRef<Rect> fromRef(JNI::ref_t);
    static JNI::PassLocalRef<Rect> fromPtr(const std::shared_ptr<Managed::Rect>&);
    template<typename... T> static JNI::PassLocalRef<Rect> create(T...);
    template<typename T> T castTo();

    FIELD_INTERFACE(left, int32_t);

    FIELD_INTERFACE(top, int32_t);

    FIELD_INTERFACE(right, int32_t);

    FIELD_INTERFACE(bottom, int32_t);

    CLASS_EXPORT static JNI::PassLocalRef<Rect> create();

    CLASS_EXPORT static JNI::PassLocalRef<Rect> create(int32_t left
        , int32_t top
        , int32_t right
        , int32_t bottom);

    CLASS_EXPORT static JNI::PassLocalRef<Rect> create(JNI::PassLocalRef<Rect> r);

    CLASS_EXPORT virtual bool equals(JNI::PassLocalRef<JNI::AnyObject> o);

    CLASS_EXPORT virtual int32_t hashCode();

    CLASS_EXPORT virtual bool isEmpty();

    CLASS_EXPORT virtual int32_t width();

    CLASS_EXPORT virtual int32_t height();

    CLASS_EXPORT virtual int32_t centerX();

    CLASS_EXPORT virtual int32_t centerY();

    CLASS_EXPORT virtual float exactCenterX();

    CLASS_EXPORT virtual float exactCenterY();

    CLASS_EXPORT virtual void setEmpty();

    CLASS_EXPORT virtual void set(int32_t left
        , int32_t top
        , int32_t right
        , int32_t bottom);

    CLASS_EXPORT virtual void set(JNI::PassLocalRef<Rect> src);

    CLASS_EXPORT virtual void offset(int32_t dx
        , int32_t dy);

    CLASS_EXPORT virtual void offsetTo(int32_t newLeft
        , int32_t newTop);

    CLASS_EXPORT virtual void inset(int32_t dx
        , int32_t dy);

    CLASS_EXPORT virtual bool contains(int32_t x
        , int32_t y);

    CLASS_EXPORT virtual bool contains(int32_t left
        , int32_t top
        , int32_t right
        , int32_t bottom);

    CLASS_EXPORT virtual bool contains(JNI::PassLocalRef<Rect> r);

    CLASS_EXPORT virtual bool intersect(int32_t left
        , int32_t top
        , int32_t right
        , int32_t bottom);

    CLASS_EXPORT virtual bool intersect(JNI::PassLocalRef<Rect> r);

    CLASS_EXPORT virtual bool setIntersect(JNI::PassLocalRef<Rect> a
        , JNI::PassLocalRef<Rect> b);

    CLASS_EXPORT virtual bool intersects(int32_t left
        , int32_t top
        , int32_t right
        , int32_t bottom);

    CLASS_EXPORT static bool intersects(JNI::PassLocalRef<Rect> a
        , JNI::PassLocalRef<Rect> b);

    CLASS_EXPORT virtual void sort();

    CLASS_EXPORT virtual void scale(float scale);

public:
    // TODO: DEFINE PRIVATE CLASS(IF NEEDED)
    class Private { public: virtual ~Private() { } };
    template<typename T> T& p() { return static_cast<T&>(*m_private); }

    // NOTE: SHOULD BE CALLED DURING MODULE INITIALIZATION
    CLASS_EXPORT static bool registerClass();

protected:
    CLASS_EXPORT Rect();

    std::unique_ptr<Private> m_private;
}; // class Rect

#undef CLASS_EXPORT

} // namespace Natives
} // namespace graphics
} // namespace android

#endif // End of File
