// Generated from ../../interfaces/HashMap.in
// Last modified: Tue Feb 21 11:04:32 2017
// THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.
#ifndef ANDROIDJNI_GENERATED_java_util_Natives_HashMap_h
#define ANDROIDJNI_GENERATED_java_util_Natives_HashMap_h

#include <androidjni/JNIIncludes.h>

namespace java {
namespace util {
namespace Managed {
class HashMap;
} // namespace Managed

namespace Natives {

class HashMap : public JNI::NativeObject {
#define CLASS_EXPORT JNI_EXPORT
public:
    class NativeBindings;
    friend class NativeBindings;
    friend class Managed::HashMap;
    
    virtual ~HashMap() { }

    // TODO: IMPLEMENT
    static HashMap* CTOR();

    static JNI::PassLocalRef<HashMap> fromRef(JNI::ref_t);
    static JNI::PassLocalRef<HashMap> fromPtr(const std::shared_ptr<Managed::HashMap>&);
    template<typename... T> static JNI::PassLocalRef<HashMap> create(T...);
    template<typename T> T castTo();

    CLASS_EXPORT static JNI::PassLocalRef<HashMap> create();

    CLASS_EXPORT static JNI::PassLocalRef<HashMap> create(int32_t capacity);

    CLASS_EXPORT static JNI::PassLocalRef<HashMap> create(int32_t capacity
        , float loadFactor);

    CLASS_EXPORT virtual void clear();

    CLASS_EXPORT virtual JNI::PassLocalRef<JNI::AnyObject> clone();

    CLASS_EXPORT virtual bool containsKey(JNI::PassLocalRef<JNI::AnyObject> key);

    CLASS_EXPORT virtual bool containsValue(JNI::PassLocalRef<JNI::AnyObject> value);

    CLASS_EXPORT virtual JNI::PassLocalRef<JNI::AnyObject> get(JNI::PassLocalRef<JNI::AnyObject> key);

    CLASS_EXPORT virtual bool isEmpty();

    CLASS_EXPORT virtual JNI::PassLocalRef<JNI::AnyObject> put(JNI::PassLocalRef<JNI::AnyObject> key
        , JNI::PassLocalRef<JNI::AnyObject> value);

    CLASS_EXPORT virtual JNI::PassLocalRef<JNI::AnyObject> remove(JNI::PassLocalRef<JNI::AnyObject> key);

    CLASS_EXPORT virtual int32_t size();

public:
    // TODO: DEFINE PRIVATE CLASS(IF NEEDED)
    class Private { public: virtual ~Private() { } };
    template<typename T> T& p() { return static_cast<T&>(*m_private); }

    // NOTE: SHOULD BE CALLED DURING MODULE INITIALIZATION
    CLASS_EXPORT static bool registerClass();

protected:
    CLASS_EXPORT HashMap();

    std::unique_ptr<Private> m_private;
}; // class HashMap

#undef CLASS_EXPORT

} // namespace Natives
} // namespace util
} // namespace java

#endif // End of File
