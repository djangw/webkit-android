// Generated from ../../interfaces/Integer.in
// Last modified: Fri Feb 24 11:50:24 2017
// THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.
#ifndef ANDROIDJNI_GENERATED_java_lang_Natives_Integer_h
#define ANDROIDJNI_GENERATED_java_lang_Natives_Integer_h

#include <androidjni/JNIIncludes.h>

namespace java {
namespace lang {
namespace Managed {
class Integer;
} // namespace Managed

namespace Natives {

class Integer : public JNI::NativeObject {
#define CLASS_EXPORT JNI_EXPORT
public:
    class NativeBindings;
    friend class NativeBindings;
    friend class Managed::Integer;
    
    virtual ~Integer() { }

    // TODO: IMPLEMENT
    static Integer* CTOR();

    static JNI::PassLocalRef<Integer> fromRef(JNI::ref_t);
    static JNI::PassLocalRef<Integer> fromPtr(const std::shared_ptr<Managed::Integer>&);
    template<typename... T> static JNI::PassLocalRef<Integer> create(T...);
    template<typename T> T castTo();

    static const int32_t MAX_VALUE = 0x7FFFFFFF;

    static const int32_t MIN_VALUE = 0x80000000;

    static const int32_t SIZE = 32;

    FIELD_INTERFACE(value, int32_t);

    CLASS_EXPORT static JNI::PassLocalRef<Integer> create(int32_t value);

    CLASS_EXPORT virtual int8_t byteValue();

    CLASS_EXPORT virtual float floatValue();

    CLASS_EXPORT virtual int32_t intValue();

    CLASS_EXPORT virtual int64_t longValue();

    CLASS_EXPORT virtual int16_t shortValue();

public:
    // TODO: DEFINE PRIVATE CLASS(IF NEEDED)
    class Private { public: virtual ~Private() { } };
    template<typename T> T& p() { return static_cast<T&>(*m_private); }

    // NOTE: SHOULD BE CALLED DURING MODULE INITIALIZATION
    CLASS_EXPORT static bool registerClass();

protected:
    CLASS_EXPORT Integer();

    std::unique_ptr<Private> m_private;
}; // class Integer

#undef CLASS_EXPORT

} // namespace Natives
} // namespace lang
} // namespace java

#endif // End of File
