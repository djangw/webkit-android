// Generated from ../../interfaces/Boolean.in
// Last modified: Fri Feb 24 11:50:24 2017
// THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.
#ifndef ANDROIDJNI_GENERATED_java_lang_Natives_Boolean_h
#define ANDROIDJNI_GENERATED_java_lang_Natives_Boolean_h

#include <androidjni/JNIIncludes.h>

namespace java {
namespace lang {
namespace Managed {
class Boolean;
} // namespace Managed

namespace Natives {

class Boolean : public JNI::NativeObject {
#define CLASS_EXPORT JNI_EXPORT
public:
    class NativeBindings;
    friend class NativeBindings;
    friend class Managed::Boolean;
    
    virtual ~Boolean() { }

    // TODO: IMPLEMENT
    static Boolean* CTOR();

    static JNI::PassLocalRef<Boolean> fromRef(JNI::ref_t);
    static JNI::PassLocalRef<Boolean> fromPtr(const std::shared_ptr<Managed::Boolean>&);
    template<typename... T> static JNI::PassLocalRef<Boolean> create(T...);
    template<typename T> T castTo();

    FIELD_INTERFACE(value, bool);

    CLASS_EXPORT static JNI::PassLocalRef<Boolean> create(bool value);

    CLASS_EXPORT virtual bool booleanValue();

public:
    // TODO: DEFINE PRIVATE CLASS(IF NEEDED)
    class Private { public: virtual ~Private() { } };
    template<typename T> T& p() { return static_cast<T&>(*m_private); }

    // NOTE: SHOULD BE CALLED DURING MODULE INITIALIZATION
    CLASS_EXPORT static bool registerClass();

protected:
    CLASS_EXPORT Boolean();

    std::unique_ptr<Private> m_private;
}; // class Boolean

#undef CLASS_EXPORT

} // namespace Natives
} // namespace lang
} // namespace java

#endif // End of File
