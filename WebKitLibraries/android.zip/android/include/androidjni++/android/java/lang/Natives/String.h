// Generated from ../../interfaces/String.in
// Last modified: Tue Feb 21 11:04:32 2017
// THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.
#ifndef ANDROIDJNI_GENERATED_java_lang_Natives_String_h
#define ANDROIDJNI_GENERATED_java_lang_Natives_String_h

#include <androidjni/JNIIncludes.h>

namespace java {
namespace lang {
namespace Managed {
class String;
} // namespace Managed

namespace Natives {

class String : public JNI::NativeObject {
#define CLASS_EXPORT JNI_EXPORT
public:
    class NativeBindings;
    friend class NativeBindings;
    friend class Managed::String;
    
    virtual ~String() { }

    // TODO: IMPLEMENT
    static String* CTOR();

    static JNI::PassLocalRef<String> fromRef(JNI::ref_t);
    static JNI::PassLocalRef<String> fromPtr(const std::shared_ptr<Managed::String>&);
    template<typename... T> static JNI::PassLocalRef<String> create(T...);
    template<typename T> T castTo();

    CLASS_EXPORT static JNI::PassLocalRef<String> create();

    CLASS_EXPORT static JNI::PassLocalRef<String> create(const JNI::PassArray<int8_t>& data);

    // NOTE: SUPPLEMENTAL, IMPLEMENT IF NEEDED
    CLASS_EXPORT static JNI::PassLocalRef<String> create(const std::string&);

    CLASS_EXPORT virtual JNI::PassArray<int8_t> getBytes();

public:
    // TODO: DEFINE PRIVATE CLASS(IF NEEDED)
    class Private { public: virtual ~Private() { } };
    template<typename T> T& p() { return static_cast<T&>(*m_private); }

    // NOTE: SHOULD BE CALLED DURING MODULE INITIALIZATION
    CLASS_EXPORT static bool registerClass();

protected:
    CLASS_EXPORT String();

    std::unique_ptr<Private> m_private;
}; // class String

#undef CLASS_EXPORT

} // namespace Natives
} // namespace lang
} // namespace java

#endif // End of File
